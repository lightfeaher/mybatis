CREATE TRIGGER tri_diarytime2
  AFTER INSERT
  ON t_dept
  FOR EACH ROW
  BEGIN
INSERT INTO t_diary VALUE(NULL,'t_dept',now());
INSERT INTO t_diary VALUE(NULL,'t_dept',now());
END;

